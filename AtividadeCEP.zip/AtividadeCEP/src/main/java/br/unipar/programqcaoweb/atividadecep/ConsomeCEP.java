package br.unipar.programqcaoweb.atividadecep;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;

public class ConsomeCEP {
    public static void main(String[] args) {
        try {
            String cep = JOptionPane.showInputDialog("Digite o CEP:");

            EnderecoDAO dao = new EnderecoDAO();
            Endereco endereco = dao.buscarPorCep(cep);

            if (endereco != null) {
                JOptionPane.showMessageDialog(null, "CEP encontrado no banco:\n" + endereco);
            } else {
                String url = "https://viacep.com.br/ws/" + cep + "/json/";
                URL urlViaCEP = new URL(url);
                HttpURLConnection conexao = (HttpURLConnection) urlViaCEP.openConnection();
                conexao.setRequestMethod("GET");

                BufferedReader leitor = new BufferedReader(new InputStreamReader(conexao.getInputStream()));
                StringBuilder resposta = new StringBuilder();
                String linha;
                while ((linha = leitor.readLine()) != null) {
                    resposta.append(linha).append("\n");
                }

                ObjectMapper mapper = new ObjectMapper();
                Endereco novoEndereco = mapper.readValue(resposta.toString(), Endereco.class);
                novoEndereco.setDataConsulta(LocalDateTime.now());

                dao.salvar(novoEndereco);
                JOptionPane.showMessageDialog(null, "CEP buscado via API e salvo:\n" + novoEndereco);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
